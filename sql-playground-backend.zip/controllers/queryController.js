const connectMySQL = require('../db');

// @desc Execute SQL query
// @route POST /api/query/execute
// @access Protected (recommend to use JWT later)
exports.executeQuery = async (req, res) => {
  const { query } = req.body;

  try {
    const connection = await connectMySQL();
    const [rows] = await connection.execute(query);

    res.status(200).json({
      success: true,
      result: rows,
    });

    await connection.end(); // Close the connection after query
  } catch (err) {
    console.error('❌ SQL Execution Error:', err.message);
    res.status(500).json({
      success: false,
      error: err.message,
    });
  }
};
