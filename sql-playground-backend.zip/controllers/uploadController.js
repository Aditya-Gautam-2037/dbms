const fs = require('fs');
const path = require('path');
const csv = require('csv-parser');
const { spawn } = require('child_process');

const detectDataType = (values) => {
  if (values.every(v => /^-?\d+$/.test(v))) return 'INTEGER';
  if (values.every(v => /^-?\d+(\.\d+)?$/.test(v))) return 'REAL';
  return 'TEXT';
};

const generateSQL = (data, tableName) => {
  const columns = Object.keys(data[0]);
  const sampleValues = columns.map(col => data.map(row => row[col]));
  const inferredTypes = sampleValues.map(detectDataType);

  const createStmt = `CREATE TABLE ${tableName} (\n  ${columns.map((col, i) => `${col} ${inferredTypes[i]}`).join(',\n  ')}\n);`;

  const insertStmts = data.map(row => {
    const values = columns.map(col => {
      const val = row[col];
      return inferredTypes[columns.indexOf(col)] === 'TEXT' ? `'${val.replace(/'/g, "''")}'` : val;
    });
    return `INSERT INTO ${tableName} (${columns.join(', ')}) VALUES (${values.join(', ')});`;
  });

  return [createStmt, ...insertStmts].join('\n');
};

const handleFileUpload = (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const uploadsDir = path.join(__dirname, '../uploads');
  const filePath = path.resolve(uploadsDir, req.file.filename); // 🔥 Absolute path
  const ext = path.extname(req.file.originalname).toLowerCase();

  console.log('🗂️ Uploaded file path:', filePath);

  // ✅ CSV FILE HANDLING
  if (ext === '.csv') {
    const results = [];
    fs.createReadStream(filePath)
      .pipe(csv())
      .on('data', (row) => results.push(row))
      .on('end', () => {
        const tableName = path.basename(req.file.originalname, '.csv').replace(/\W+/g, '_');
        const sqlScript = generateSQL(results, tableName);

        fs.writeFileSync(path.join(uploadsDir, `${tableName}.sql`), sqlScript);

        res.status(200).json({
          success: true,
          message: '✅ File uploaded and SQL generated',
          filename: req.file.filename,
          sql: sqlScript,
        });
      });

  // 🖼️ IMAGE FILE HANDLING (OCR → CSV → SQL)
  } else if (['.jpg', '.jpeg', '.png', '.webp'].includes(ext)) {
    const tableName = path.basename(req.file.originalname, ext).replace(/\W+/g, '_');
    const scriptPath = path.resolve(__dirname, 'image_to_sql.py'); // 🔥 Absolute Python script path

    if (!fs.existsSync(filePath)) {
      console.error('❌ Image file not found:', filePath);
      return res.status(500).json({ error: 'Image file not found for OCR' });
    }

    console.log('🐍 Running OCR:', scriptPath, filePath, tableName);

    const py = spawn('python', [scriptPath, filePath, tableName]);

    let pyOutput = '';
    let pyError = '';

    py.stdout.on('data', (data) => pyOutput += data.toString());
    py.stderr.on('data', (data) => pyError += data.toString());

    py.on('close', (code) => {
      console.log('📤 Python Output:\n', pyOutput);
      console.error('🐛 Python Error:\n', pyError);
      console.log('❌ Exit code:', code);
    
      if (code !== 0 || /Traceback|Error/i.test(pyError)) {
        return res.status(500).json({ 
          error: '❌ Failed to process image via OCR',
          stderr: pyError,
          stdout: pyOutput,
          exitCode: code
        });
      }
    
      // Save .sql and respond
      fs.writeFileSync(path.join(uploadsDir, `${tableName}.sql`), pyOutput);
    
      res.status(200).json({
        success: true,
        message: '📸 Image uploaded and SQL generated via OCR',
        filename: req.file.filename,
        sql: pyOutput,
      });
    });    
  } else {
    res.status(400).json({ error: '❌ Unsupported file type. Only .csv or image files are accepted.' });
  }
};

module.exports = { handleFileUpload };
