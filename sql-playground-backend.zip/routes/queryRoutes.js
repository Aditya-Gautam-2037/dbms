const express = require('express');
const router = express.Router();
const { executeQuery } = require('../controllers/queryController');

// Example route to run SQL queries
router.post('/run-query', executeQuery);

module.exports = router;
