# Code Citations

## License: unknown
https://github.com/GNOME/vte/tree/4cd5c1283f6e38b6c5feb96c23d912656191fe31/.gitlab-ci/docs.html

```
->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title
```


## License: unknown
https://github.com/mz5c/learn_php/tree/73346291d2eb116e8255e0a12f848dd5ed7d37ba/2016c/dir20160414c/login.php

```
>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
```


## License: GPL_3_0
https://github.com/SaaimaNishat/CourierManagementSystem/tree/9b4c379c2b1de040df60374b4af0eecc290c0eee/cms/index.php

```
lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel
```


## License: unknown
https://github.com/studentsaathi/setinterval-localstorag-login/tree/7e08a67962ecc23f350d458d6cb0d33c54c5f32d/Async-Prog-Assignment-Template_644177%20%283%29/Async-Prog-Assignment-Template/login.html

```
="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles/login.css">
</head>
<body>
    <
```


## License: unknown
https://github.com/seans888/my-project-linckt/tree/c6a4c0a4547f37d017cc9dac6f296825c184ab02/Application/linckt/login.php

```
="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type
```

