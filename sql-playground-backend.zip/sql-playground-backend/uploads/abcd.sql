CREATE TABLE abcd (
  Ssn INTEGER,
  Dname TEXT
);
INSERT INTO abcd (Ssn, Dname) VALUES (123456789, 'Research');
INSERT INTO abcd (Ssn, Dname) VALUES (333445555, 'Research');
INSERT INTO abcd (Ssn, Dname) VALUES (999887777, 'Research');
INSERT INTO abcd (Ssn, Dname) VALUES (987654321, 'Research');
INSERT INTO abcd (Ssn, Dname) VALUES (666884444, 'Research');
INSERT INTO abcd (Ssn, Dname) VALUES (453453453, 'Research');
INSERT INTO abcd (Ssn, Dname) VALUES (987987987, 'Research');
INSERT INTO abcd (Ssn, Dname) VALUES (888665555, 'Research');
INSERT INTO abcd (Ssn, Dname) VALUES (123456789, 'Administration');
INSERT INTO abcd (Ssn, Dname) VALUES (333445555, 'Administration');
INSERT INTO abcd (Ssn, Dname) VALUES (999887777, 'Administration');
INSERT INTO abcd (Ssn, Dname) VALUES (987654321, 'Administration');
INSERT INTO abcd (Ssn, Dname) VALUES (666884444, 'Administration');
INSERT INTO abcd (Ssn, Dname) VALUES (453453453, 'Administration');
INSERT INTO abcd (Ssn, Dname) VALUES (987987987, 'Administration');
INSERT INTO abcd (Ssn, Dname) VALUES (888665555, 'Administration');
INSERT INTO abcd (Ssn, Dname) VALUES (123456789, 'Headquarters');
INSERT INTO abcd (Ssn, Dname) VALUES (333445555, 'Headquarters');
INSERT INTO abcd (Ssn, Dname) VALUES (999887777, 'Headquarters');
INSERT INTO abcd (Ssn, Dname) VALUES (987654321, 'Headquarters');
INSERT INTO abcd (Ssn, Dname) VALUES (666884444, 'Headquarters');
INSERT INTO abcd (Ssn, Dname) VALUES (453453453, 'Headquarters');
INSERT INTO abcd (Ssn, Dname) VALUES (987987987, 'Headquarters');
INSERT INTO abcd (Ssn, Dname) VALUES (888665555, 'Headquarters');
