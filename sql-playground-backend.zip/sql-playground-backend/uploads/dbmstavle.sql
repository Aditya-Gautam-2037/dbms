CREATE TABLE dbmstavle (
  E.Fname TEXT,
  E.Lname TEXT,
  S.Fname TEXT,
  S.Lname TEXT
);
INSERT INTO dbmstavle (E.Fname, E.Lname, S.Fname, S.Lname) VALUES ('John', 'Smith', 'Franklin', 'Wong');
INSERT INTO dbmstavle (E.Fname, E.Lname, S.Fname, S.Lname) VALUES ('Franklin', 'Wong', 'James', 'Borg');
INSERT INTO dbmstavle (E.Fname, E.Lname, S.Fname, S.Lname) VALUES ('Alicia', 'Zelaya', 'Jennifer', 'Wallace');
INSERT INTO dbmstavle (E.Fname, E.Lname, S.Fname, S.Lname) VALUES ('Jennifer', 'Wallace', 'James', 'Borg');
INSERT INTO dbmstavle (E.Fname, E.Lname, S.Fname, S.Lname) VALUES ('Ramesh', 'Narayan', 'Franklin', 'Wong');
INSERT INTO dbmstavle (E.Fname, E.Lname, S.Fname, S.Lname) VALUES ('Joyce', 'English', 'Franklin', 'Wong');
INSERT INTO dbmstavle (E.Fname, E.Lname, S.Fname, S.Lname) VALUES ('Ahmad', 'Jabbar', 'Jennifer', 'Wallace');
